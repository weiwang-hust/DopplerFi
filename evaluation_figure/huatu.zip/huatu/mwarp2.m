clear;
data  = xlsread('warp0727_plot.xlsx', 'A2:M11');
% data2 = xlsread('warp.xlsx', 'B87:N97');
distance1=zeros(6,1);
warp_ber_los=zeros(6,1);
warp_throughput1_los=zeros(6,1);
warp_throughput2_los=zeros(6,1);
distance1(1:6,1)=data(1:6,1);
warp_ber_los(1:6,1)=[1 1 1 1 1 1]'-data(1:6,11);
% E1=std([1544 1454 1463 1428 1747 1787],1)
% E2=std([1587 1625 1461],1)
warp_throughput1_los(1:6,1)=1568*data(1:6,11);
warp_throughput2_los(1:6,1)=1e6/140*data(1:6,11);
% [hAx,hLine1,hLine2]=plotyy(distance,warp_ber_los,distance,warp_throughput_los);
% set(hLine1,'Marker','*');
% set(hLine2,'Marker','^');
% ylabel(hAx(1),'BER');
% ylabel(hAx(2),'Throughput');
% xlabel('Distance(m)');
% title('BER and throughout of different distance');

distance2=zeros(4,1);
warp_ber_nlos=zeros(4,1);
warp_throughput1_nlos=zeros(4,1);
warp_throughput2_nlos=zeros(4,1);
distance2(1:4,1)=data(7:10,1);
warp_throughput1_nlos(1:4,1)=1582*data(7:10,11);
warp_throughput2_nlos(1:4,1)=1e6/140*data(7:10,11);
warp_ber_nlos(1:4,1)=[1 1 1 1]'-data(7:10,11);

% [hAx,hLine1,hLine2]=plotyy(distance,warp_ber,distance,warp_throughput);
% set(hLine1,'Marker','*');
% set(hLine2,'Marker','^');
% ylabel(hAx(1),'BER');
% ylabel(hAx(2),'Throughput');
% xlabel('Distance(m)');
% title('BER and throughout of different distance');
figure;
plot(distance1,warp_ber_los,'-*','linewidth',1.5);
hold on;plot(distance2,warp_ber_nlos,'-^','linewidth',1.5);
h1=legend('LOS','NLOS');
set(h1,'FontSize',14,'fontname','Times New Roman');
ylabel('BER','FontSize',14,'fontname','Times New Roman');
xlabel('Distance(m)','FontSize',14,'fontname','Times New Roman');

figure;
plot(distance1,warp_throughput1_los,'-*','linewidth',1.5);
hold on;plot(distance2,warp_throughput1_nlos,'-^','linewidth',1.5);
% hold on;errorbar(distance1,warp_throughput1_los,[E1 E1 E1 E1 E1 E1],'r','linewidth',1);
% hold on;errorbar(distance2,warp_throughput1_nlos,[E2 E2 E2 E2],'g','linewidth',1);
h2=legend('LOS','NLOS');
set(h2,'FontSize',14,'fontname','Times New Roman');
ylabel('Throughput(bps)','FontSize',14,'fontname','Times New Roman');
xlabel('Distance(m)','FontSize',14,'fontname','Times New Roman');

figure;
plot(distance1,warp_throughput2_los,'-*','linewidth',1.5);
hold on;plot(distance2,warp_throughput2_nlos,'-^','linewidth',1.5);
h2=legend('LOS','NLOS');
set(h2,'FontSize',14,'fontname','Times New Roman');
ylabel('Throughput(bps)','FontSize',14,'fontname','Times New Roman');
xlabel('Distance(m)','FontSize',14,'fontname','Times New Roman');