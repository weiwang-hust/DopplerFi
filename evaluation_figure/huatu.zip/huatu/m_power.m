clear;
data  = xlsread('power0728.xlsx', 'B2:L8');
power=zeros(7,1);
ber=zeros(7,1);
throughput1=zeros(7,1);
throughput2=zeros(7,1);
power(1:7,1)=data(1:7,2);

ber(1:7,1)=[1 1 1 1 1 1 1]'-data(1:7,10);
throughput1(1:7,1)=8439*data(1:7,10);
% E=std([2203 287.5 2198 2586 3045 31378 24761]);
throughput2(1:7,1)=1e6/140*data(1:7,10);
figure;bar(power,ber); xlabel('Power(dBm)','FontSize',14,'fontname','Times New Roman');ylabel('BER','FontSize',14,'fontname','Times New Roman');ylim([0 0.2]);
figure;bar(power,throughput1); xlabel('Power(dBm)','FontSize',14,'fontname','Times New Roman');ylabel('Throughput(bps)','FontSize',14,'fontname','Times New Roman');ylim([6000 8000]);
figure;bar(power,throughput2); xlabel('Power(dBm)','FontSize',14,'fontname','Times New Roman');ylabel('Throughput(bps)','FontSize',14,'fontname','Times New Roman');ylim([6000 6700]);